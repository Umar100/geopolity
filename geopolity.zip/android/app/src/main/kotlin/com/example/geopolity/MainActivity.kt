package com.example.geopolity

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
