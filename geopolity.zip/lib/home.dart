import 'package:flutter/material.dart';
import 'package:webview_flutter/webview_flutter.dart';

// void main() => runApp(WViewPage());

class WViewPage extends StatefulWidget {
  @override
  _WViewPageState createState() => _WViewPageState();
}

class _WViewPageState extends State<WViewPage> {
  bool isLoading = true;

  final _key = UniqueKey();

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
        title: 'theGeopolity',
        home: Scaffold(
          backgroundColor: Colors.red[900],
          body: Stack(
            children: [
              Padding(
                padding: const EdgeInsets.fromLTRB(0.0, 20.0, 0.0, 0.0),
                child: WebView(
                  key: _key,
                  initialUrl: 'https://thegeopolity.com/',
                  javascriptMode: JavascriptMode.unrestricted,
                  onPageFinished: (finish) {
                    setState(() {
                      isLoading = false;
                    });
                  },
                ),
              ),
              isLoading
                  ? Column(
                    children: [
                      LinearProgressIndicator(
                        backgroundColor: Colors.blue[900],
                      ),
                    ],
                  )
                  : Stack(),
            ],
          ),
        ));
  }
}
